/*
    Neighbourhood Map OF Jaipur
*/

var map, infoWindow;

         function initMap() {
             map = new google.maps.Map(
                 document.getElementById('map'), {
                     center: {
                         lat: 26.912434,
                         lng: 75.787271
                     },
                     zoom: 12,
                     mapTypeControl: false
                 }
             );
             infowindow = new google.maps.InfoWindow();
             ko.applyBindings(new model());
         }

         function mapError() {
             document.getElementById('map-error').innerHTML = "Error in Map!";
         }

         //Locations data to be shown on map
var placesData = [{
        title: 'Amer Fort',
        location: {
            lat: 26.985487,
            lng: 75.851345
        },
        show: true,
        selected: false,
        venueId: '4bb16be4f964a52063923ce3'
    },
    {
        title: 'Jal Mahal',
        location: {
            lat: 26.965604,
            lng: 75.859205
        },
        show: true,
        selected: false,
        venueId: '4d4146261bd2a143d98efb7c'
    },
    {
        title: 'Jantar Mantar',
        location: {
            lat: 26.924762,
            lng: 75.82456
        },
        show: true,
        selected: false,
        venueId: '4bb594102f70c9b668628430'
    },
    {
        title: 'Albert Hall',
        location: {
            lat: 26.911676,
            lng: 75.819469
        },
        show: true,
        selected: false,
        venueId: '4c613a9f048b9521ebb44278'
    },
    {
        title: 'Jaigarh Fort',
        location: {
            lat: 26.985088,
            lng: 75.845593
        },
        show: true,
        selected: false,
        venueId: '4c8b41fd1797236a768b6988'
    },
    {
        title: 'Birla Mandir',
        location: {
            lat: 26.892161,
            lng: 75.81553
        },
        show: true,
        selected: false,
        venueId: '4ce6a853d8be6a315cb25642'
    },
    {
        title: 'Nahargarh Fort',
        location: {
            lat: 26.937317,
            lng: 75.81548
        },
        show: true,
        selected: false,
        venueId: '4c95da8e82b56dcbd9a0dcaa'
    },
    {
        title: 'Hawa Mahal',
        location: {
            lat: 26.923936,
            lng: 75.826744
        },
        show: true,
        selected: false,
        venueId: '4f1d22f8e4b044fd373c32bb'
    },
    {
        title: 'Galta Ji',
        location: {
            lat: 26.91679,
            lng: 75.858903
        },
        show: true,
        selected: false,
        venueId: '4ecde4a86d86bf39f27bd383'
    },
    {
        title: 'Kanak Ghati Garden',
        location: {
            lat: 26.968058,
            lng: 75.849052
        },
        show: true,
        selected: false,
        venueId: '50c87c20e4b0edda945e5fdc'
    }
];


var model = function()
{
    var self = this;
    self.errorDisplay = ko.observable('');
    self.mapArray = [];

    for (var i = 0; i < placesData.length; i++) {
        var place = new google.maps.Marker({
            position: {
                lat: placesData[i].location.lat,
                lng: placesData[i].location.lng
            },
            map: map,
            title: placesData[i].title,
            show: ko.observable(placesData[i].show),
            selected: ko.observable(placesData[i].selected),
            venueid: placesData[i].venueId, // venue id used for foursquare
            animation: google.maps.Animation.DROP
        });
        self.mapArray.push(place);
    }

    // Animation function for markers
    self.Bounce = function(marker) {
        marker.setAnimation(google.maps.Animation.BOUNCE);
        setTimeout(function() {
            marker.setAnimation(null);
        }, 600);
    };

    // API information to each marker
    self.addApiInfo = function(marker) {
        $.ajax({
            url: "https://api.foursquare.com/v2/venues/" + marker.venueid + '?client_id=5M3HNREN1RLQTVSFWOFPFZ4KTRF2IPAKJL2KFMBGM0LIFKDN&client_secret=PSS1OCR2IYQ45ZJZPVRFLQ5U4HXCA2XWJITT5NJRIV0PWXAC&v=20131016',
            dataType: "json",
            success: function(data) {
                // stores result to display the likes and ratings
                var result = data.response.venue;
                // to add likes and ratings to markers
                marker.likes = result.hasOwnProperty('likes') ? result.likes.summary : '';
                marker.rating = result.hasOwnProperty('rating') ? result.rating : '';
            },
            // alert message if there is error in recievng json
            error: function(e) {
                self.errorDisplay("Foursquare data is unavailable. Please try again later.");
            }
        });
    };

    //function to add information about API to the markers
    var addMarkerInfo = function(marker) {

        //add API items to each marker
        self.addApiInfo(marker);

        //add the click event listener to marker
        marker.addListener('click', function() {
            //set this marker to the selected state

            self.setSelected(marker);
        });
    };

    //  iterate through mapArray and add marker API information
    for (i = 0; i < self.mapArray.length; i++) {
        addMarkerInfo(self.mapArray[i]);
    }
    // create a searchText for the input field
    self.searchText = ko.observable('');

    //every keydown is called from input box
    self.filterList = function() {
        //variable for search text
        var currentText = self.searchText();
        infowindow.close();
        //list for user search
        if (currentText.length === 0) {
            self.setAllShow(true);
        } else {
            for (var i = 0; i < self.mapArray.length; i++) {
                // to check whether the searchText is there in the mapArray
                if (self.mapArray[i].title.toLowerCase().indexOf(currentText.toLowerCase()) > -1) {
                    self.mapArray[i].show(true);
                    self.mapArray[i].setVisible(true);
                } else {
                    self.mapArray[i].show(false);
                    self.mapArray[i].setVisible(false);
                }
            }
        }
        infowindow.close();
    };

    // to show all the markers
    self.setAllShow = function(marker) {
        for (var i = 0; i < self.mapArray.length; i++) {
            self.mapArray[i].show(marker);
            self.mapArray[i].setVisible(marker);
        }
    };

    // function to make all the markers unselected
    self.setAllUnselected = function() {
        for (var i = 0; i < self.mapArray.length; i++) {
            self.mapArray[i].selected(false);
        }
    };
    self.currentLocation = self.mapArray[0];

    // function select the markers and show the likes and ratings
    self.setSelected = function(location) {
        self.setAllUnselected();
        location.selected(true);
        self.currentLocation = location;

        Likes = function() {
            if (self.currentLocation.likes === '' || self.currentLocation.likes === undefined) {
                return "Likes not available for this location";
            } else {
                return "Location has " + self.currentLocation.likes;
            }
        };
        // function to show rating and if not then no rating to display
        Rating = function() {
            if (self.currentLocation.rating === '' || self.currentLocation.rating === undefined) {
                return "Ratings not  available for this location";
            } else {
                return "Location is rated " + self.currentLocation.rating;
            }
        };

        var InfoWindow = "<h5>" + self.currentLocation.title + "</h5>" + "<div>" + Likes() + "</div>" + "<div>" + Rating() + "</div>";
        infowindow.setContent(InfoWindow);
        infowindow.open(map, location);
        self.Bounce(location);
    };
};